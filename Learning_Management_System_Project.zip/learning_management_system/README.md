# Learning Management System (LMS)

A beginner-friendly Flask + SQLite web application for a college mini-project.

## Features
- Student and teacher registration/login
- Password hashing
- Course listing and course creation by teachers
- Student course enrollment
- Lesson notes and optional YouTube video links
- Three-question Python quiz with automatic scoring
- Student dashboard with quiz history
- SQLite database created automatically

## Requirements
- Python 3.10 or later
- Internet browser

## Run on Windows
1. Extract the ZIP file.
2. Open the extracted `learning_management_system` folder in VS Code.
3. Open Terminal in that folder.
4. Run:
   ```bash
   python -m venv venv
   venv\Scripts\activate
   pip install -r requirements.txt
   python app.py
   ```
5. Open `http://127.0.0.1:5000` in your browser.

## Demo accounts
- Teacher: `teacher@lms.com` / `teacher123`
- Student: `student@lms.com` / `student123`

The database and demo accounts are initialized on the first run. Delete `lms.db` to reset the demo database.

## YouTube video link
Teachers can add a YouTube URL to a lesson. This starter version stores the link; it does not download or host videos.

## Important before public deployment
This is an educational starter project, not production-ready. Change `app.secret_key`, add CSRF protection, validate video URLs, add authorization checks for every feature, use HTTPS, and disable Flask debug mode before deployment.
