from flask import Flask, render_template, request, redirect, url_for, session, flash
import sqlite3
from functools import wraps
from werkzeug.security import generate_password_hash, check_password_hash

app = Flask(__name__)
app.secret_key = "change-this-secret-key"
DB = "lms.db"

def get_db():
    conn = sqlite3.connect(DB)
    conn.row_factory = sqlite3.Row
    return conn

def init_db():
    with get_db() as db:
        db.executescript("""
        CREATE TABLE IF NOT EXISTS users (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            name TEXT NOT NULL,
            email TEXT UNIQUE NOT NULL,
            password TEXT NOT NULL,
            role TEXT NOT NULL CHECK(role IN ('student','teacher'))
        );
        CREATE TABLE IF NOT EXISTS courses (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            title TEXT NOT NULL,
            description TEXT NOT NULL,
            teacher_id INTEGER NOT NULL,
            FOREIGN KEY(teacher_id) REFERENCES users(id)
        );
        CREATE TABLE IF NOT EXISTS enrollments (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            student_id INTEGER NOT NULL,
            course_id INTEGER NOT NULL,
            UNIQUE(student_id, course_id)
        );
        CREATE TABLE IF NOT EXISTS lessons (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            course_id INTEGER NOT NULL,
            title TEXT NOT NULL,
            content TEXT NOT NULL,
            video_url TEXT DEFAULT ''
        );
        CREATE TABLE IF NOT EXISTS quiz_results (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            student_id INTEGER NOT NULL,
            course_id INTEGER NOT NULL,
            score INTEGER NOT NULL,
            total INTEGER NOT NULL
        );
        """)
        # Demo accounts are created only when the database is empty.
        if db.execute("SELECT COUNT(*) FROM users").fetchone()[0] == 0:
            db.execute("INSERT INTO users(name,email,password,role) VALUES(?,?,?,?)",
                       ("Demo Teacher", "teacher@lms.com", generate_password_hash("teacher123"), "teacher"))
            db.execute("INSERT INTO users(name,email,password,role) VALUES(?,?,?,?)",
                       ("Demo Student", "student@lms.com", generate_password_hash("student123"), "student"))
            teacher_id = db.execute("SELECT id FROM users WHERE email='teacher@lms.com'").fetchone()["id"]
            db.execute("INSERT INTO courses(title,description,teacher_id) VALUES(?,?,?)",
                       ("Introduction to Python", "Learn Python basics, variables, conditions, and loops.", teacher_id))
            course_id = db.execute("SELECT id FROM courses WHERE title='Introduction to Python'").fetchone()["id"]
            db.execute("INSERT INTO lessons(course_id,title,content,video_url) VALUES(?,?,?,?)",
                       (course_id, "Python Basics", "Python is a beginner-friendly programming language. Start with print(), variables, and data types.", "https://www.youtube.com/"))
    print("Database ready.")

def login_required(fn):
    @wraps(fn)
    def wrapper(*args, **kwargs):
        if "user_id" not in session:
            flash("Please log in first.", "warning")
            return redirect(url_for("login"))
        return fn(*args, **kwargs)
    return wrapper

@app.route("/")
def index():
    with get_db() as db:
        courses = db.execute("""SELECT courses.*, users.name AS teacher_name
                                FROM courses JOIN users ON users.id=courses.teacher_id
                                ORDER BY courses.id DESC""").fetchall()
    return render_template("index.html", courses=courses)

@app.route("/register", methods=["GET", "POST"])
def register():
    if request.method == "POST":
        name = request.form.get("name", "").strip()
        email = request.form.get("email", "").strip().lower()
        password = request.form.get("password", "")
        role = request.form.get("role", "student")
        if not name or not email or len(password) < 6 or role not in ("student", "teacher"):
            flash("Enter valid details. Password must contain at least 6 characters.", "danger")
            return redirect(url_for("register"))
        try:
            with get_db() as db:
                db.execute("INSERT INTO users(name,email,password,role) VALUES(?,?,?,?)",
                           (name, email, generate_password_hash(password), role))
            flash("Account created. Please log in.", "success")
            return redirect(url_for("login"))
        except sqlite3.IntegrityError:
            flash("That email is already registered.", "danger")
    return render_template("register.html")

@app.route("/login", methods=["GET", "POST"])
def login():
    if request.method == "POST":
        email = request.form.get("email", "").strip().lower()
        password = request.form.get("password", "")
        with get_db() as db:
            user = db.execute("SELECT * FROM users WHERE email=?", (email,)).fetchone()
        if user and check_password_hash(user["password"], password):
            session.clear()
            session["user_id"] = user["id"]
            session["name"] = user["name"]
            session["role"] = user["role"]
            return redirect(url_for("dashboard"))
        flash("Incorrect email or password.", "danger")
    return render_template("login.html")

@app.route("/logout")
def logout():
    session.clear()
    flash("You have logged out.", "success")
    return redirect(url_for("index"))

@app.route("/dashboard")
@login_required
def dashboard():
    with get_db() as db:
        if session["role"] == "teacher":
            courses = db.execute("SELECT * FROM courses WHERE teacher_id=? ORDER BY id DESC",
                                 (session["user_id"],)).fetchall()
            return render_template("teacher_dashboard.html", courses=courses)
        courses = db.execute("""SELECT courses.*, users.name AS teacher_name
                                FROM enrollments JOIN courses ON courses.id=enrollments.course_id
                                JOIN users ON users.id=courses.teacher_id
                                WHERE enrollments.student_id=? ORDER BY courses.id DESC""",
                             (session["user_id"],)).fetchall()
        results = db.execute("""SELECT quiz_results.*, courses.title FROM quiz_results
                                JOIN courses ON courses.id=quiz_results.course_id
                                WHERE student_id=? ORDER BY quiz_results.id DESC""",
                             (session["user_id"],)).fetchall()
    return render_template("student_dashboard.html", courses=courses, results=results)

@app.route("/courses/new", methods=["GET", "POST"])
@login_required
def new_course():
    if session["role"] != "teacher":
        flash("Only teachers can create courses.", "danger")
        return redirect(url_for("dashboard"))
    if request.method == "POST":
        title = request.form.get("title", "").strip()
        description = request.form.get("description", "").strip()
        if title and description:
            with get_db() as db:
                db.execute("INSERT INTO courses(title,description,teacher_id) VALUES(?,?,?)",
                           (title, description, session["user_id"]))
            flash("Course created successfully.", "success")
            return redirect(url_for("dashboard"))
        flash("Please fill in all fields.", "danger")
    return render_template("new_course.html")

@app.route("/courses/<int:course_id>")
def course_detail(course_id):
    with get_db() as db:
        course = db.execute("""SELECT courses.*, users.name AS teacher_name
                               FROM courses JOIN users ON users.id=courses.teacher_id
                               WHERE courses.id=?""", (course_id,)).fetchone()
        if not course:
            flash("Course not found.", "danger")
            return redirect(url_for("index"))
        lessons = db.execute("SELECT * FROM lessons WHERE course_id=? ORDER BY id", (course_id,)).fetchall()
        enrolled = False
        if "user_id" in session and session["role"] == "student":
            enrolled = bool(db.execute("SELECT id FROM enrollments WHERE student_id=? AND course_id=?",
                                       (session["user_id"], course_id)).fetchone())
    return render_template("course_detail.html", course=course, lessons=lessons, enrolled=enrolled)

@app.route("/courses/<int:course_id>/enroll", methods=["POST"])
@login_required
def enroll(course_id):
    if session["role"] != "student":
        flash("Only student accounts can enroll.", "warning")
        return redirect(url_for("course_detail", course_id=course_id))
    with get_db() as db:
        exists = db.execute("SELECT id FROM courses WHERE id=?", (course_id,)).fetchone()
        if not exists:
            flash("Course not found.", "danger")
            return redirect(url_for("index"))
        db.execute("INSERT OR IGNORE INTO enrollments(student_id,course_id) VALUES(?,?)",
                   (session["user_id"], course_id))
    flash("You are enrolled in this course.", "success")
    return redirect(url_for("course_detail", course_id=course_id))

@app.route("/courses/<int:course_id>/lessons/new", methods=["GET", "POST"])
@login_required
def new_lesson(course_id):
    if session["role"] != "teacher":
        flash("Only teachers can add lessons.", "danger")
        return redirect(url_for("dashboard"))
    with get_db() as db:
        course = db.execute("SELECT * FROM courses WHERE id=? AND teacher_id=?",
                            (course_id, session["user_id"])).fetchone()
    if not course:
        flash("Course not found or you do not own it.", "danger")
        return redirect(url_for("dashboard"))
    if request.method == "POST":
        title = request.form.get("title", "").strip()
        content = request.form.get("content", "").strip()
        video_url = request.form.get("video_url", "").strip()
        if title and content:
            with get_db() as db:
                db.execute("INSERT INTO lessons(course_id,title,content,video_url) VALUES(?,?,?,?)",
                           (course_id, title, content, video_url))
            flash("Lesson added.", "success")
            return redirect(url_for("course_detail", course_id=course_id))
        flash("Lesson title and content are required.", "danger")
    return render_template("new_lesson.html", course=course)

@app.route("/courses/<int:course_id>/quiz", methods=["GET", "POST"])
@login_required
def quiz(course_id):
    if session["role"] != "student":
        flash("Quiz is available to student accounts.", "warning")
        return redirect(url_for("course_detail", course_id=course_id))
    with get_db() as db:
        enrolled = db.execute("SELECT id FROM enrollments WHERE student_id=? AND course_id=?",
                              (session["user_id"], course_id)).fetchone()
        course = db.execute("SELECT * FROM courses WHERE id=?", (course_id,)).fetchone()
    if not course:
        flash("Course not found.", "danger")
        return redirect(url_for("index"))
    if not enrolled:
        flash("Enroll in the course before taking the quiz.", "warning")
        return redirect(url_for("course_detail", course_id=course_id))
    questions = [
        {"q":"Which function displays text in Python?", "options":["show()", "print()", "write()"], "answer":"print()"},
        {"q":"Which symbol is used for a comment in Python?", "options":["//", "#", "<!--"], "answer":"#"},
        {"q":"Which data type stores True or False?", "options":["bool", "str", "list"], "answer":"bool"}
    ]
    if request.method == "POST":
        score = sum(1 for i, q in enumerate(questions) if request.form.get(f"q{i}") == q["answer"])
        with get_db() as db:
            db.execute("INSERT INTO quiz_results(student_id,course_id,score,total) VALUES(?,?,?,?)",
                       (session["user_id"], course_id, score, len(questions)))
        return render_template("quiz_result.html", course=course, score=score, total=len(questions))
    return render_template("quiz.html", course=course, questions=questions)

if __name__ == "__main__":
    init_db()
    app.run(debug=True)
